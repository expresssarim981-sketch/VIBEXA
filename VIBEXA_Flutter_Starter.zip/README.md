# VIBEXA Flutter Starter

Starter UI for VIBEXA by ZYVORAQ Technologies.

## Included
- Dark purple UI theme
- Home screen
- Search field
- Room category chips
- Trending room cards
- Recommended room
- Bottom navigation
- Demo room preview dialogs

## Run
1. Install Flutter SDK.
2. From this folder run: `flutter pub get`
3. Run: `flutter run`

Note: Voice chat, authentication, backend, real wallet, gifts, moderation, and admin panel are not yet connected. This is the initial UI starter.

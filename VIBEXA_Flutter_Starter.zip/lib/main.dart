import 'package:flutter/material.dart';

void main() => runApp(const VibexaApp());

class VibexaApp extends StatelessWidget {
  const VibexaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VIBEXA',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF100D19),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9B5CFF),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedTab = 0;

  final rooms = const [
    RoomData('Late Night Vibes', '12 people', '🎧', Color(0xFF6D35C8)),
    RoomData('Friends Hangout', '8 people', '🌙', Color(0xFFB13D8B)),
    RoomData('Music & Chill', '24 people', '🎵', Color(0xFF286EAD)),
    RoomData('Pakistan Lounge', '16 people', '🇵🇰', Color(0xFF218B70)),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: _header()),
            SliverToBoxAdapter(child: _search()),
            SliverToBoxAdapter(child: _categories()),
            SliverToBoxAdapter(child: _sectionTitle('🔥 Trending Rooms', 'See all')),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => RoomCard(room: rooms[index]),
                  childCount: rooms.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.08,
                ),
              ),
            ),
            SliverToBoxAdapter(child: _sectionTitle('✨ Recommended for you', 'See all')),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                child: _recommendedRoom(),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF191322),
        indicatorColor: const Color(0xFF6335A4).withValues(alpha: 0.4),
        selectedIndex: selectedTab,
        onDestinationSelected: (index) => setState(() => selectedTab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.explore_rounded), label: 'Discover'),
          NavigationDestination(icon: Icon(Icons.mic_rounded), label: 'Party'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_rounded), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
        child: Row(
          children: [
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('VIBEXA', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 2)),
                Text('Connect • Chat • Party', style: TextStyle(color: Colors.white60, fontSize: 11)),
              ],
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(
                color: const Color(0xFF251A38),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFF7044A5)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.monetization_on, color: Color(0xFFFFD66B), size: 18),
                  SizedBox(width: 5),
                  Text('120', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(width: 4),
                  Icon(Icons.add_circle, color: Color(0xFFB987FF), size: 18),
                ],
              ),
            ),
            const SizedBox(width: 10),
            const CircleAvatar(
              backgroundColor: Color(0xFF6D35C8),
              child: Icon(Icons.person, color: Colors.white),
            ),
          ],
        ),
      );

  Widget _search() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: TextField(
          decoration: InputDecoration(
            hintText: 'Search rooms, users...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: const Color(0xFF211A2D),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
      );

  Widget _categories() => SizedBox(
        height: 52,
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          scrollDirection: Axis.horizontal,
          children: const [
            CategoryChip(label: 'All', icon: '✨', active: true),
            CategoryChip(label: 'Music', icon: '🎵'),
            CategoryChip(label: 'Chat', icon: '💬'),
            CategoryChip(label: 'Games', icon: '🎮'),
            CategoryChip(label: 'Friends', icon: '👥'),
          ],
        ),
      );

  Widget _sectionTitle(String title, String action) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
        child: Row(
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Spacer(),
            Text(action, style: const TextStyle(color: Color(0xFFB987FF))),
          ],
        ),
      );

  Widget _recommendedRoom() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF51268B), Color(0xFF25163B)]),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            const CircleAvatar(radius: 28, backgroundColor: Colors.white12, child: Text('🎤', style: TextStyle(fontSize: 25)),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('VIBEXA Official Room', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                Text('Meet new people and vibe together', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ),
            FilledButton(
              onPressed: () => _showRoomDialog('VIBEXA Official Room'),
              child: const Text('Join'),
            ),
          ],
        ),
      );

  void _showRoomDialog(String roomName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF251A35),
        title: Text(roomName),
        content: const Text('Room preview. Live voice functionality will be connected in the next development phase.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      ),
    );
  }
}

class CategoryChip extends StatelessWidget {
  final String label;
  final String icon;
  final bool active;
  const CategoryChip({super.key, required this.label, required this.icon, this.active = false});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: Chip(
          avatar: Text(icon),
          label: Text(label),
          backgroundColor: active ? const Color(0xFF6735A7) : const Color(0xFF211A2D),
          side: BorderSide(color: active ? const Color(0xFF9B5CFF) : Colors.transparent),
        ),
      );
}

class RoomData {
  final String title;
  final String people;
  final String emoji;
  final Color color;
  const RoomData(this.title, this.people, this.emoji, this.color);
}

class RoomCard extends StatelessWidget {
  final RoomData room;
  const RoomCard({super.key, required this.room});

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: const Color(0xFF251A35),
            title: Text(room.title),
            content: const Text('Room preview. Live audio will be integrated in a later build.'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [room.color, const Color(0xFF21162E)]),
            borderRadius: BorderRadius.circular(18),
          ),
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: Colors.redAccent, borderRadius: BorderRadius.circular(8)),
                  child: const Text('LIVE', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                ),
                const Spacer(),
                const Icon(Icons.people_alt_rounded, size: 15),
                const SizedBox(width: 4),
                Text(room.people, style: const TextStyle(fontSize: 11)),
              ]),
              const Spacer(),
              Center(child: Text(room.emoji, style: const TextStyle(fontSize: 38))),
              const Spacer(),
              Text(room.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 3),
              const Text('Tap to join room', style: TextStyle(fontSize: 11, color: Colors.white70)),
            ],
          ),
        ),
      );
}
